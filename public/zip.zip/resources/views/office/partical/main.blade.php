@include('office.partical.header')
@yield('content')
@include('office.partical.footer')


