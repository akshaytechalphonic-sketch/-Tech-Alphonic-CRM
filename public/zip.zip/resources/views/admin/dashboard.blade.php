@extends('admin.partical.main')
@push('title')
<title>Dashboard | Admin</title>
@endpush

@push('custom-css')

@endpush

@section('content')
@push('custom-css')
@endpush

















@push('custom-js')


@endpush
@endsection
