@include('admin.partical.header')
@yield('content')
@include('admin.partical.footer')


