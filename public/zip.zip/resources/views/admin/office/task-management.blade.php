@extends('admin.partical.main')
@push('title')
<title>Dashboard | Admin</title>
@endpush

@push('custom-css')

@endpush

@section('content')

        <div class="main-content">
          <!-- write-body-content here start -->
            <div class="pages-content">
                <div class="dash-tabs d-flex justify-content-between align-items-end mb-3">
                <div class="d-flex align-items-center gap-3 w-100">
                <div class="row w-100">
                    <div class="col-3">
                            <label for="" class="form-label">Select Department </label>
                            <select class="form-select" aria-label="Default select example">
                            <option selected=""> Select </option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div class="col-3">
                            <label for="" class="form-label">Select Team </label>
                            <select class="form-select" aria-label="Default select example">
                            <option selected=""> Select </option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div class="col-3">
                            <label for="" class="form-label">Select Employee </label>
                            <select class="form-select" aria-label="Default select example">
                            <option selected=""> Select </option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div class="col-3">
                        <div class="dash-tabs-filter  d-flex align-items-end h-100 gap-3">                       
                            <div class="create-client-btn">
                                <a href="#!" type="submit" class="d-flex align-items-center gap-2"> <img src="{{ asset('public/admin/assets/images/icons')}}/plus.png" alt="">Submit</a>
                            </div>                            
                        </div>
                    </div>
                    
                </div>
                <!-- <ul class="nav nav-pills" id="pills-tab" role="tablist">
                        <li class="nav-item me-3">
                            <button class="client-main-btn" type="button" >Employee <img src="{{ asset('public/admin/assets/images/icons')}}/double-arrow.png" alt=""> </button>
                        </li> 
                         <li class="nav-item" role="presentation">
                            <button class="nav-link active rounded-pill" id="pills-Allclient-tab" data-bs-toggle="pill" data-bs-target="#pills-Allclient" type="button" role="tab" aria-controls="pills-Allclient" aria-selected="true">All Employees </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill" id="pills-Activeclient-tab" data-bs-toggle="pill" data-bs-target="#pills-Activeclient" type="button" role="tab" aria-controls="pills-Activeclient" aria-selected="false">Departments </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill" id="pills-InActiveclient-tab" data-bs-toggle="pill" data-bs-target="#pills-InActiveclient" type="button" role="tab" aria-controls="pills-InActiveclient" aria-selected="false">Designations </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill" id="pills-Completedclient-tab" data-bs-toggle="pill" data-bs-target="#pills-Completedclient" type="button" role="tab" aria-controls="pills-Completedclient" aria-selected="false">Employee Shift </button>
                        </li> 
                       
                    </ul> -->
                </div>

                <div class="dash-tabs-filter  d-flex gap-3">
                        <div class="filter-btn">
                            <a href="#!" class="d-flex align-items-center gap-2"  data-bs-toggle="modal" data-bs-target="#taskfilterModel"> <img src="{{ asset('public/admin/assets/images/icons')}}/setting.png" alt="">Filter</a>
                        </div>
                        <div class="create-client-btn">
                            <a href="#!"   data-bs-toggle="modal" data-bs-target="#addProjectModel" class="d-flex align-items-center gap-2"> <img src="{{ asset('public/admin/assets/images/icons')}}/plus.png" alt="">Add Project</a>
                        </div>
                        
                    </div>
                </div>

                <div class="dash-tabs-content no-scrollbar">
                    <div class="tab-content" id="pills-tabContent">

                        <div class="tab-pane fade show active" id="pills-Allclient" role="tabpanel" aria-labelledby="pills-Allclient-tab" tabindex="0">

                            <div class="table-responsive">
                                <table  class="table example">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                    All              
                                                </div>

                                            </th>
                                            <th>SNo.</th>
                                            <th>Project Name </th>
                                            <th>Client name </th>
                                            <th>Team </th>
                                            <th>Assignee</th>
                                            <th>Estimate</th>
                                            <th>Spent Time</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Sample Rows -->
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>Maria Sretnenko</td>
                                            <td>Development </td>
                                            <td>Manish</td>
                                            <td>2d 2h 20m</td>
                                            <td>2d 4h</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="employee-profile.php"><span class="iconify" data-icon="basil:eye-outline" data-inline="false" style="font-size: 24px;"></span></a>
                                                    </i></li> 
                                                </ul>
                                            </td>
                                        </tr>
                                       
                                     

                                       
                                      
                                        

                                        <!-- Add more rows here -->
                                    </tbody>
                                </table>
                            </div>

                        </div>

                      
                       
                    </div>
                </div>

            </div>
            
            


          <!-- write-body-content here end -->
        </div>
        
      </div>
    </section>

    <div class="modal fade" id="addProjectModel" tabindex="-1" aria-labelledby="addProjectModelLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <form action="" class="w-100">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center">
                    <h1 class="modal-title fs-5" id="addProjectModelLabel">Add Project</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 mb-3">
                            <label for="" class="form-label">Project Name </label>
                            <input type="text" class="form-control" placeholder="Project Name" name="project_name">                                                            
                        </div>
                        <div class="col-lg-6 col-md-6 mb-3">
                            <label for="" class="form-label">Client Name </label>
                            <input type="text" class="form-control" placeholder="Project Name" name="project_name">                                                            
                        </div>
                        <div class="col-lg-6 col-md-6 mb-3">
                            <label for="" class="form-label">Team</label>
                            <select class="form-select" aria-label="Default select example">
                                <option value="" selected disabled> Select Task Group</option>
                                <option value="One">One</option>
                                <option value="Complete">Two</option>
                                <option value="Three">Three</option>
                            </select>
                        </div> 
                        <div class="col-lg-6 col-md-6 mb-3">
                            <label for="" class="form-label">Assign Employee</label>
                            <select class="form-select" aria-label="Default select example">
                                <option value="" disabled selected=""> Select Employee</option>
                                <option value="One">One</option>
                                <option value="Complete">Two</option>
                                <option value="Three">Three</option>
                            </select>
                        </div>
                        <div class="col-lg-6 col-md-6 mb-3">
                            <label for="" class="form-label">Reporter  </label>
                            <select class="form-select" aria-label="Default select example">
                                <option value="na" selected=""> Select Reporter</option>
                                <option value="One">One</option>
                                <option value="Complete">Two</option>
                                <option value="Three">Three</option>
                            </select>
                        </div> 
                        <div class="col-lg-6 col-md-6 mb-3">
                            <label for="" class="form-label">Estimate </label>
                            <input type="time" class="form-control">                                
                        </div>
                        <div class="col-lg-6 col-md-6 mb-3">
                            <label for="" class="form-label">Priority  </label>
                            <select class="form-select" aria-label="Default select example">
                                <option value="Active" selected=""> Low</option>
                                <option value="Inactive">Medium</option>
                                <option value="Complete">High</option>
                                <option value="Droped">Urgent</option>
                            </select>
                        </div>      
                        <div class="col-lg-12 col-md-12 mb-3">
                            <label for="" class="form-label">Work Description </label>
                            <textarea class="form-control" id="" rows="3" placeholder="Add some description of the task"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer d-flex align-item-center justify-content-between">
                    <button type="Submit" class="btn-dark" id="success">Submit</button>
                </div>
            </div>
            </form>
        </div>
    </div>

    <div class="search-box-mob">
      <div class="close-search-bar">
        <img
          width="30"
          height="30"
          src="https://img.icons8.com/ios/30/close-window.png"
          alt="close-window"
        />
      </div>

      <script>
          const tabs = document.querySelectorAll('.nav-link');
            const createClientBtns = document.querySelectorAll('.create-client-btn');
            console.log(tabs);
            console.log(createClientBtns);
            
            // Function to update the visibility of create-client-btns
            function updateButtons() {
                // Hide all create-client-btns
                createClientBtns.forEach(btn => btn.style.display = 'none');
            
                // Get the active tab
                const activeTab = document.querySelector('.nav-link.active');
                if (activeTab) {
                    const tabIndex = Array.from(tabs).indexOf(activeTab);
                    if (createClientBtns[tabIndex]) {
                        // Show the corresponding create-client-btn
                        createClientBtns[tabIndex].style.display = 'flex';
                    }
                }
            }
            
            // Add event listeners to tabs
            tabs.forEach(tab => {
                tab.addEventListener('click', updateButtons);
            });
      </script>
      @push('custom-js')


      @endpush
      @endsection
      