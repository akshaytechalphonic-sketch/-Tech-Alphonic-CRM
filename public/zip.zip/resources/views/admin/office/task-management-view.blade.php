<?php include '../partials/header.php';?>

<style>
  .custom-dropdown {
    width: 250px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 2px;
    font-family: 'Arial', sans-serif;
    position: relative;
    cursor: pointer;
  }

  .dropdown-header {
    font-weight: bold;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
    /* text-align: center; */
  }

  .dropdown-items {
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    z-index: 100;
    display: none;
  }

  .dropdown-items.visible {
    display: block;
  }

  .dropdown-item {
    padding: 10px;
    border-radius: 6px;
    display: flex;
    flex-direction: column;
    gap: 5px;
    transition: background-color 0.2s;
    cursor: pointer;
  }

  .dropdown-item:hover {
    background-color: #f4f4f4;
  }

  .dropdown-item.selected {
    background-color: #f0f8ff;
    border: 1px solid #d0e8ff;
    border-right:4px solid #3c2fc0;
  }

  .project-id {
    font-size: 12px;
    color: #666666;
  }

  .project-title {
    font-size: 14px;
    font-weight: bold;
    color: #333333;
  }

  .view-details {
    font-size: 12px;
    color: #007bff;
    text-decoration: none;
    align-self: flex-start;
  }

  .view-details:hover {
    text-decoration: underline;
  }
</style>
        <div class="main-content">
          <!-- write-body-content here start -->
            <div class="pages-content">
                <div class="dash-tabs d-flex justify-content-between align-items-end mb-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="">
                    <div class="custom-dropdown" id="dropdown">
  <div class="dropdown-header form-select" id="dropdownHeader">
    Current Projects
  </div>
  <div class="dropdown-items hidden" id="dropdownItems">
    <div class="dropdown-item" data-value="medical-app">
      <span class="project-id">PN001245</span>
      <span class="project-title">Medical App (iOS native)</span>
      <a href="#" class="view-details">View details</a>
    </div>
    <div class="dropdown-item" data-value="food-delivery">
      <span class="project-id">PN001245</span>
      <span class="project-title">Food Delivery Service</span>
      <a href="#" class="view-details">View details</a>
    </div>
    <div class="dropdown-item" data-value="fortune-website">
      <span class="project-id">PN001245</span>
      <span class="project-title">Fortune website</span>
      <a href="#" class="view-details">View details</a>
    </div>
    <div class="dropdown-item" data-value="planner-app">
      <span class="project-id">PN001245</span>
      <span class="project-title">Planner App</span>
      <a href="#" class="view-details">View details</a>
    </div>
    <div class="dropdown-item" data-value="time-tracker">
      <span class="project-id">PN001245</span>
      <span class="project-title">Time tracker - personal account</span>
      <a href="#" class="view-details">View details</a>
    </div>
    <div class="dropdown-item" data-value="internal-project">
      <span class="project-id">PN001245</span>
      <span class="project-title">Internal Project</span>
      <a href="#" class="view-details">View details</a>
    </div>
  </div>
</div>




                    </div>
                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                         
                         <li class="nav-item" role="presentation">
                            <button class="nav-link active rounded-pill" id="pills-Allclient-tab" data-bs-toggle="pill" data-bs-target="#pills-Allclient" type="button" role="tab" aria-controls="pills-Allclient" aria-selected="true">All Task </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill" id="pills-Activeclient-tab" data-bs-toggle="pill" data-bs-target="#pills-Activeclient" type="button" role="tab" aria-controls="pills-Activeclient" aria-selected="false">To Do </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill" id="pills-InActiveclient-tab" data-bs-toggle="pill" data-bs-target="#pills-InActiveclient" type="button" role="tab" aria-controls="pills-InActiveclient" aria-selected="false">In Progress </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill" id="pills-Completedclient-tab" data-bs-toggle="pill" data-bs-target="#pills-Completedclient" type="button" role="tab" aria-controls="pills-Completedclient" aria-selected="false">In Review </button>
                        </li> 
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill" id="pills-Doneclient-tab" data-bs-toggle="pill" data-bs-target="#pills-Doneclient" type="button" role="tab" aria-controls="pills-Doneclient" aria-selected="false">Done </button>
                        </li> 
                       
                    </ul>
                </div>

                <div class="dash-tabs-filter  d-flex gap-3">
                        <div class="filter-btn">
                            <a href="#!" class="d-flex align-items-center gap-2"  data-bs-toggle="modal" data-bs-target="#taskfilterModel"> <img src="../assets/images/icons/setting.png" alt="">Filter</a>
                        </div>
                        <div class="create-client-btn">
                            <a href="#!"  data-bs-toggle="modal" data-bs-target="#addProjectModel" class="d-flex align-items-center gap-2"> <img src="../assets/images/icons/plus.png" alt="">Add Project</a>
                        </div>
                        
                    </div>
                </div>

                <div class="dash-tabs-content no-scrollbar">
                    <div class="tab-content" id="pills-tabContent">

                        <div class="tab-pane fade show active" id="pills-Allclient" role="tabpanel" aria-labelledby="pills-Allclient-tab" tabindex="0">

                            <div class="table-responsive">
                                <table  class="table example">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                    All              
                                                </div>

                                            </th>
                                            <th>SNo.</th>
                                            <th>Task Name  </th>
                                            <th>Spent Time</th>
                                            <th>Estimate</th>
                                            <th>Assignee</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Sample Rows -->
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                         
                                       
                                       
                                     

                                       
                                      
                                        

                                        <!-- Add more rows here -->
                                    </tbody>
                                </table>
                            </div>

                        </div>

                        <div class="tab-pane fade" id="pills-Activeclient" role="tabpanel" aria-labelledby="pills-Activeclient-tab" tabindex="0">
                            <div class="table-responsive ">
                                <table  class="table example">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                    All              
                                                </div>
                                            </th>
                                            <th>SNo.</th>
                                            <th>Task Name  </th>
                                            <th>Spent Time</th>
                                            <th>Estimate</th>
                                            <th>Assignee</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Sample Rows -->
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  gray-bg ">To Do</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                         
                                       
                                       
                                     

                                       
                                      
                                        

                                        <!-- Add more rows here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-InActiveclient" role="tabpanel" aria-labelledby="pills-InActiveclient-tab" tabindex="0">
                            <div class="table-responsive">
                                <table  class="table example">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                    All              
                                                </div>

                                            </th>
                                            <th>SNo.</th>
                                            <th>Task Name  </th>
                                            <th>Spent Time</th>
                                            <th>Estimate</th>
                                            <th>Assignee</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Sample Rows -->
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  blue-bg ">In Progress</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                         
                                       
                                       
                                     

                                       
                                      
                                        

                                        <!-- Add more rows here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-Completedclient" role="tabpanel" aria-labelledby="pills-Completedclient-tab" tabindex="0">
                            <div class="table-responsive">
                                <table  class="table example">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                    All              
                                                </div>

                                            </th>
                                            <th>SNo.</th>
                                            <th>Task Name  </th>
                                            <th>Spent Time</th>
                                            <th>Estimate</th>
                                            <th>Assignee</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Sample Rows -->
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">               
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  pink-bg ">In Review</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                         
                                       
                                       
                                     

                                       
                                      
                                        

                                        <!-- Add more rows here -->
                                    </tbody>
                                </table>
                               
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-Doneclient" role="tabpanel" aria-labelledby="pills-Doneclient-tab" tabindex="0">
                            <div class="table-responsive">
                                <table  class="table example">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                    All              
                                                </div>

                                            </th>
                                            <th>SNo.</th>
                                            <th>Task Name  </th>
                                            <th>Spent Time</th>
                                            <th>Estimate</th>
                                            <th>Assignee</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Sample Rows -->
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="">
                                                </div>
                                            </td>
                                            <td>1</td>
                                            <td>Medical App (iOS native)</td>
                                            <td>2d 4h</td>
                                            <td>2d 2h 20m</td>
                                            <td>Manish</td>
                                            <td><span class="badge  succes-bg ">Done</span>
                                                </td>
                                            <td>
                                                <ul class="action-icons edit d-flex list-unstyled gap-2 mb-0">
                                                    <li><span class="iconify" data-icon="iconoir:trash" data-inline="false" style="font-size: 24px;"></span></li>
                                                    <li><a href="task-management-view.php"><span class="iconify" data-icon="solar:pen-outline" data-inline="false" style="font-size: 24px;"></span></a></li>
                                                </ul>
                                            </td>
                                        </tr>









                                        <!-- Add more rows here -->
                                    </tbody>
                                </table>

                            </div>
                        </div>
                       
                    </div>
                </div>

            </div>
            
            


          <!-- write-body-content here end -->
        </div>
        
      </div>
    </section>

    <div class="search-box-mob">
      <div class="close-search-bar">
        <img
          width="30"
          height="30"
          src="https://img.icons8.com/ios/30/close-window.png"
          alt="close-window"
        />
      </div>

      <script>
        // Get references to elements
const dropdownHeader = document.getElementById("dropdownHeader");
const dropdownItems = document.getElementById("dropdownItems");
const dropdown = document.getElementById("dropdown");

// Toggle dropdown visibility
dropdownHeader.addEventListener("click", () => {
  dropdownItems.classList.toggle("visible");
});

// Handle item selection
dropdownItems.addEventListener("click", (event) => {
  const selectedItem = event.target.closest(".dropdown-item");
  if (selectedItem) {
    const projectTitle = selectedItem.querySelector(".project-title").innerText;
    dropdownHeader.innerText = projectTitle;

    // Close the dropdown
    dropdownItems.classList.remove("visible");

    // Remove "selected" class from all items
    document.querySelectorAll(".dropdown-item").forEach((item) => {
      item.classList.remove("selected");
    });

    // Mark the clicked item as selected
    selectedItem.classList.add("selected");

    // Optionally log or handle the selected value
    console.log("Selected value:", selectedItem.dataset.value);
  }
});

// Close dropdown if clicked outside
document.addEventListener("click", (event) => {
  if (!dropdown.contains(event.target)) {
    dropdownItems.classList.remove("visible");
  }
});





      </script>
      <?php include '../partials/footer.php';?>