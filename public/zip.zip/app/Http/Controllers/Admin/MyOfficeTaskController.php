<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\OfficeDepartments;
use App\Models\OfficeEmployees;
use App\Models\OfficeDesignations;
use App\Models\OfficeTeams;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class MyOfficeTaskController extends Controller
{
    public function index(){
        return view('admin.office.task-management');
    }
}