<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class ArtisanTerminalController extends Controller
{
    public function execute(Request $request)
    {
        if ($request->isMethod('post')) {
            $command = $request->input('command'); // Get command from input
    
            try {
                Artisan::call($command);
                $output = Artisan::output();
                return response()->json(['output' => $output]);
            } catch (\Exception $e) {
                return response()->json(['error' => $e->getMessage()], 500);
            }
        }
        return view('welcome');
        
    }
}