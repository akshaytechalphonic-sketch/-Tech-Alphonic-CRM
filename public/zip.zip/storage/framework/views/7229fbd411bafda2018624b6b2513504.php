
<?php $__env->startPush('title'); ?>
    <title>Dashboard | Admin</title>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!--work on other object-->
<script src="https://cdn.socket.io/4.0.1/socket.io.min.js"></script>
    <?php
        $route = \Request::route()->getName();
    ?>
    <style>
        .employeeList:hover{
            background-color: #f7f7f7;
        }
        #remarks::-webkit-scrollbar-track, .listEmp::-webkit-scrollbar-track
        {
        	    background-color: rgba(var(--bs-light-rgb), var(--bs-bg-opacity)) !important;
        }
        
        #remarks::-webkit-scrollbar,.listEmp::-webkit-scrollbar
        {
        	width: 6px;
        	    background-color: rgba(var(--bs-light-rgb), var(--bs-bg-opacity)) !important;
        }
        
        #remarks::-webkit-scrollbar-thumb, .listEmp::-webkit-scrollbar-thumb
        {
        	background-color: #c0c0c0;
        }
        #selectedFile{
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
        }
        .appendedMessage .file{
            width: 100%;
            max-width:50%;font-size:13px;;
            height: 150px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .customProgress{
            width: 250px;
            height: 5px;
            background: #ffffff;
        }
        .innerCustomProgress{
            width: 20%;
            height: 100%;
            background: #000000;
        }
        .customProgress.rounded-pill.overflow-hidden:before {
            content: attr(data-percentage);
            position: absolute;
            top: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        .addNewChat {
            display:flex;
            justify-content:center;
            align-items:center;
            width:45px;
            height:45px;
            border-radius:1000px;
            background-color: var(--bs-dark-bg-subtle) !important;
            cursor:pointer;
            position:absolute;
            bottom:5%;
            right:5%
        }
        .messageTime{
            font-size: 10px;
        }
    </style>
    <div class="main-content">
        <!-- write-body-content here start -->
        <div class="pages-content">
             <div class="row m-0">
                    <div class="col-4 mb-0">
                        <div class="bg-white rounded p-3 pb-0 position-relative listEmp" id="chattedEMpList"  style="height: 100vh; max-height: calc(97vh - 100px); overflow: hidden scroll;">
                            <div class="step-title">
                                <div class="d-flex align-items-center  mb-2">
                                    <input class="form-control me-2 shadow-none border" type="search" placeholder="Search name..." /><a class="btn rounded-pill fs-5 p-2 py-1 border" href="<?php echo e(url()->current()); ?>"><i class="fa-solid fa-rotate"></i></a>
                                </div>
                                <ul class="list-group list-group-flush">
                                    <?php if(isset($chat_with) && !str_contains(json_encode($chattedEMp, true),'"user_id":'.$chat_with->id)): ?>
                                    <li data-id="<?php echo e($chat_with->id); ?>" class="list-group-item d-flex align-items-center employeeList <?php echo e($chat_with->id == $chat_with->id ? 'bg-light' : ''); ?>" style="cursor:pointer" onclick="return window.location.href='<?php echo e(route('office_employee.chats.singleChat',['emp_base64'=> base64_encode(json_encode(['id'=>$chat_with->id,'name'=>$chat_with->id]))])); ?>'">
                                        <div class="profileImage overflow-hidden rounded-pill me-3 h-100" style="width: 45px;height: 45px;">
                                          <img style="aspect-ratio: 1;object-fit: cover;" src="https://media.istockphoto.com/id/1682296067/photo/happy-studio-portrait-or-professional-man-real-estate-agent-or-asian-businessman-smile-for.jpg?s=612x612&w=0&k=20&c=9zbG2-9fl741fbTWw5fNgcEEe4ll-JegrGlQQ6m54rg=" />
                                        </div>
                                        <div class="profileContent w-75">
                                            <span><?php echo e($chat_with->name); ?></span><br>
                                            <small class="text-truncate d-block w-100"></small>
                                        </div>
                                    </li>
                                <?php endif; ?>
                                    <?php $__currentLoopData = $chattedEMp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-id="<?php echo e($item->user_id); ?>" class="list-group-item d-flex align-items-center employeeList <?php echo e(isset($chat_with->id) && $chat_with->id == $item->user_id ? 'bg-light' : ''); ?>" style="cursor:pointer" onclick="return window.location.href='<?php echo e(route('office_employee.chats.singleChat',['emp_base64'=> base64_encode(json_encode(['id'=>$item->user_id,'name'=>$item->name]))])); ?>'">
                                        <div class="profileImage overflow-hidden rounded-pill me-3 h-100" style="width: 45px;height: 45px;">
                                          <img style="aspect-ratio: 1;object-fit: cover;" src="https://media.istockphoto.com/id/1682296067/photo/happy-studio-portrait-or-professional-man-real-estate-agent-or-asian-businessman-smile-for.jpg?s=612x612&w=0&k=20&c=9zbG2-9fl741fbTWw5fNgcEEe4ll-JegrGlQQ6m54rg=" />
                                        </div>
                                        <div class="profileContent w-75">
                                            <span><?php echo e($item->name); ?></span><br>
                                            <small class="text-truncate d-block w-100"><?php echo e($item->message); ?> </small>
                                        </div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="addNewChat shadow" data-bs-toggle="modal" data-bs-target="#addNewChat"><i class="fa-solid fa-plus"></i></div>
                        </div>
                    </div>
                    <div class="col-8">
                        <div class="bg-white rounded p-3 h-100">
                            <?php if(isset($chat_with)): ?>
                            <div class="step-title ">
                                <h6 class="d-flex align-items-center"> 
                                <div class="profileImage overflow-hidden rounded-pill me-3 h-100" style="width: 45px;height: 45px;">
                                    <img style="aspect-ratio: 1;object-fit: cover;" src="https://media.istockphoto.com/id/1682296067/photo/happy-studio-portrait-or-professional-man-real-estate-agent-or-asian-businessman-smile-for.jpg?s=612x612&w=0&k=20&c=9zbG2-9fl741fbTWw5fNgcEEe4ll-JegrGlQQ6m54rg=" />
                                </div>
                                <div class="profileContent w-75">
                                    <span><?php echo e($chat_with->name); ?></span><br>
                                    <small class="fw-light"><?php echo e($chat_with->designation->designation_name); ?></small>
                                </div>
                                <a href="tel:<?php echo e(str_contains($chat_with->mobile_no, "91") ? '' : '91'.$chat_with->mobile_no); ?>" class="me-4"><i class="fa-solid fa-phone"></i></a>
                                <a href="mailto:<?php echo e($chat_with->email); ?>"><i class="fa-solid fa-envelope"></i></a>
                                </h6>
                            </div>
                            <div class="position-relative">
                                
                                <div id="remarks" data-id="<?php echo e($chat_with->id); ?>" class="bg-light mb-3 rounded p-3 d-flex flex-column-reverse overflow-y-scroll" style="scroll-behavior: smooth;height: calc(77vh - 100px);">
                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $file = json_decode($mess->file, true);
                                        ?>
                                        <?php if($mess->sender_id == $chat_with->id): ?>
                                        <div class="w-100 d-flex <?php echo e($mess->file != null ? 'flex-column' : ''); ?> justify-content-start mb-2 appendedMessage">
                                                <?php if($mess->file != null): ?>
                                            <div class="file bg-dark-subtle text-dark rounded-3 rounded-bottom-0 position-relative">
                                                <i class="fa-solid fa-file display-6 mb-3"></i>
                                                <span class="fs-6 fw-light mb-2 px-3 text-center"><?php echo e($file['name']); ?></span>
                                                <div class="actions position-relative">
                                                    <a href="<?php echo e(url('public/'.$file['path'])); ?>" target="_blank" class="me-2"><i class="fa-solid fa-eye"></i></a><a href="<?php echo e('public/'.$file['path']); ?>" download="<?php echo e($file['name']); ?>"><i class="fa-solid fa-circle-down"></i></a>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <div class="overflow-hidden mb-0 text-dark rounded-3 <?php echo e($mess->file != null ? 'rounded-top-0 border-top' : ''); ?>  text-wrap p-2 py-1 m-0 shadow-sm d-inline-block bg-dark-subtle" style="max-width:50%;font-size:13px;word-break: break-all;">
                                                <?php echo !filter_var($mess->message, FILTER_VALIDATE_URL) ? $mess->message : "<a class='link-primary' target='_blank' href='{$mess->message}'>{$mess->message}</a>"; ?><br>
                                                <small class="messageTime"><?php echo e(date('h:i A',strtotime($mess->created_at))); ?></small>
                                            </div>
                                        </div>
                                        <?php else: ?>
                                        <div class="w-100 d-flex <?php echo e($mess->file != null ? 'flex-column align-items-end' : 'justify-content-end'); ?> mb-2 appendedMessage">
                                            <?php if($mess->file != null): ?>
                                            <div class="file bg-dark text-white rounded-3 rounded-bottom-0 position-relative">
                                                <i class="fa-solid fa-file display-6 mb-3"></i>
                                                <span class="fs-6 fw-light mb-2 px-3 text-center"><?php echo e($file['name']); ?></span>
                                                <div class="actions position-relative">
                                                    <a href="<?php echo e(url('public/'.$file['path'])); ?>" target="_blank" class="me-2"><i class="fa-solid fa-eye"></i></a><a href="<?php echo e('public/'.$file['path']); ?>" download="<?php echo e($file['name']); ?>"><i class="fa-solid fa-circle-down"></i></a>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <div class="overflow-hidden mb-0 text-white rounded-3 <?php echo e($mess->file != null ? 'rounded-top-0 w-100 border-top' : ''); ?> text-wrap p-2 py-1 m-0 shadow-sm d-inline-block bg-dark" style="max-width:50%;font-size:13px;word-break: break-all;">
                                                <?php echo !filter_var($mess->message, FILTER_VALIDATE_URL) ? $mess->message : "<a class='link-primary' target='_blank' href='{$mess->message}'>{$mess->message}</a>"; ?><br>
                                                <small class="float-end messageTime"><?php echo e(date('h:i A',strtotime($mess->created_at))); ?></small>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                                <div id="selectedFile" class="d-flex justify-content-center align-items-center flex-column z-3 text-white d-none" style="backdrop-filter: brightness(0.2);">
                                </div>
                            </div>
                            <form class="row m-0" id="sendMessage" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="col-12 customEditor" contenteditable="true">
                                        
                                </div>
                                
                                <div class="col-12 pe-0 d-flex p-0">
                                    <label type="button" for="selectFile" class="btn me-2 rounded-pill fs-5 p-0 btn btn-outline-light text-dark shadow-sm px-3 d-flex justify-content-center align-items-center"><i class="fa-solid fa-file"></i></label>
                                    
                                    <input name="message" id="messageInput" class="form-control w-100 rounded-5 shadow-sm" placeholder="Write Message" rows="1" autocomplete="off" required>
                                    <input type="hidden" value="<?php echo e($login_employee->id); ?>" name="sender_id">
                                    <input type="hidden" value="<?php echo e($chat_with->id); ?>" name="receiver_id">
                                    <input name="file" type="file"id="selectFile" class="d-none">
                                    <!--</textarea>-->
                                    <button type="submit" class="btn btn-primary ms-2 rounded-pill"><i class="fa-solid fa-paper-plane"></i></button>
                                </div>
                            </form>
                            <?php else: ?>
                            <div class="w-100 h-100 text-muted d-flex justify-content-center align-items-center flex-column">
                                <i class="display-2 fa-regular fa-message mb-3"></i>
                                <h4>Select your friend...</h4>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
        </div>
        <!-- write-body-content here end -->
    </div>

    </div>
    </section>
</div>
<!--data-bs-toggle="modal" data-bs-target="#addNewChat"-->

<!-- Modal -->
<div class="modal fade" id="addNewChat" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="addNewChatLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header border-none">
        <h1 class="modal-title fs-5" id="addNewChatLabel"><br></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <input class="form-control rounded-0 border-none shadow-none" type="search" placeholder="Search name..." />
      <div class="modal-body listEmp">
        
        <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-id="<?php echo e($item->user_id); ?>" class="list-group-item d-flex align-items-center employeeList" style="cursor:pointer" onclick="return window.location.href='<?php echo e(route('office_employee.chats.singleChat',['emp_base64'=> base64_encode(json_encode(['id'=>$item->id,'name'=>$item->name]))])); ?>'">
                                        <div class="profileImage overflow-hidden rounded-pill me-3 h-100" style="width: 45px;height: 45px;">
                                          <img style="aspect-ratio: 1;object-fit: cover;" src="https://media.istockphoto.com/id/1682296067/photo/happy-studio-portrait-or-professional-man-real-estate-agent-or-asian-businessman-smile-for.jpg?s=612x612&w=0&k=20&c=9zbG2-9fl741fbTWw5fNgcEEe4ll-JegrGlQQ6m54rg=" />
                                        </div>
                                        <div class="profileContent w-75">
                                            <span><?php echo e($item->name); ?></span><br>
                                            <small class="text-truncate d-block w-100"><?php echo e($item->message); ?></small>
                                        </div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
      </div>
    </div>
  </div>
</div>
    <div class="search-box-mob">
        <div class="close-search-bar">
            <img width="30" height="30" src="https://img.icons8.com/ios/30/close-window.png" alt="close-window" />
        </div>
        
        <?php $__env->startPush('custom-js'); ?>
<script>
    function makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
}
        function getCurrentTime() {
            let now = new Date();
            let hours = now.getHours();
            let minutes = now.getMinutes();
            let ampm = hours >= 12 ? 'PM' : 'AM';

            hours = hours % 12 || 12; // Convert 24-hour format to 12-hour format
            hours = hours < 10 ? '0' + hours : hours; // Add leading zero to hours
            minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero to minutes

            let timeString = hours + ':' + minutes + ' ' + ampm;

            return timeString;
        }
            $(document).ready(function(){
                function appendFileData(fileName, fileSize){
                    $('#selectedFile').append(`<i class="fa-solid fa-file display-4 mb-3"></i><span class="fs-4 fw-light ">${fileName}</span> <span class="fs-6 fw-bold ">Size : ${fileSize}</span>`);
                    return;
                }
                
            // $('.customEditor').on('input',function(event){
            //     $('#messageInput').val(messageInput)
            // })
            $('#selectFile').change(function(event){
                $('#selectedFile').html('')
                const ext = ['pdf','csv','excel','zipper','video','powerpoint'];
                
                var file = event.target.files[0]; // Get the selected file
                if (file) {
                    console.log(file)
                    var fileName = file.name; // Get file name
                    var fileExtension = fileName.split('.').pop().toLowerCase(); // Get file extension
                    var fileType = file.type; // Get MIME type
                    const fileSize = file.size < 1024 ? file.size + " Bytes" : file.size < 1024 * 1024 ? (file.size / 1024).toFixed(2) + " KB" : (file.size / (1024 * 1024)).toFixed(2) + " MB";

                    console.log(fileSize)
                    $('#selectedFile').removeClass('d-none')
                    appendFileData(fileName, fileSize);
                    
                }

            })
            $('#sendMessage').submit(function(e){
                // var form = $(this);
                e.preventDefault();
                sendMessage($(this).find('input[name=message]').val())
            })
            const socket = io("https://live-chat-xzaw.onrender.com", {
                transports: ["polling", "websocket"]
            });


            let myUserId = <?php echo e($login_employee->id); ?>;
    
            if (myUserId) {
                socket.emit("register", myUserId);
            }
            
            <?php if(isset($chat_with)): ?>
            function sendMessage(message) {
                const receiverId = <?php echo e($chat_with->id); ?>;
                
                if (myUserId && receiverId && message) {
                    
let formData = new FormData();

// Append file
let file = $('input[name=file]')[0].files[0]; 
if (file) {
    formData.append('file', file);
}

// Serialize form inputs (excluding file)
let serializedData = $('form').serializeArray();
$.each(serializedData, function (index, field) {
    formData.append(field.name, field.value);
});
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(url()->current()); ?>",
                        data: formData, // serializes the form's elements.
                        contentType: false, 
                        processData: false, 
                        beforeSend: function() {
                                $('#selectedFile').addClass('d-none')
                                $('#selectedFile').html('')
                                if(file){
                                    selfAppendMessage(message,'start',receiverId,file.name);
                                }else{
                                    socket.emit("private message", {
                        senderId: myUserId,
                        receiverId: receiverId,
                        message: message
                    });
                                    selfAppendMessage(message,'start',receiverId);
                                }
                        },
                        xhr: function () {
                        let xhr = new window.XMLHttpRequest();
                        xhr.upload.onprogress = function (event) {
                            if (event.lengthComputable) {
                                console.log(randomMakeId)
                                let percentComplete = Math.round((event.loaded / event.total) * 100)+'%';
                                $(`.file[data-uploadid=${randomMakeId}]`).find('.customProgress').attr('data-percentage',percentComplete)
                                $(`.file[data-uploadid=${randomMakeId}]`).find('.customProgress .innerCustomProgress').css({"width":percentComplete})
                            }
                            };
                            return xhr;
                        },
                        success: function(data)
                        {
                            if(file){
                                socket.emit("private message", {
                                    senderId: myUserId,
                                    receiverId: receiverId,
                                    message: message,
                                    other:{url:data.url , name:file.name}
                                });
                            }
                          
                          $(`.file[data-uploadid=${randomMakeId}]`).find('.actions .customProgress').remove()
                          $(`.file[data-uploadid=${randomMakeId}]`).find('.actions').append(`<a href="${data.url}" target="_blank" class="me-2"><i class="fa-solid fa-eye"></i></a><a href="${data.url}" download="240841_small.mp4"><i class="fa-solid fa-circle-down"></i></a>`)
                          $('#messageInput').val('')
                          $('input[name=file]').val(null)
                        }
                    });
                }
            }
            <?php endif; ?>
    
            socket.on("receive message", data => {
                console.log('receive message',data)
                appendMessage(data,'end');
            });
    
            function appendMessage(data,type) {
                let appendFile = (other) => {
                     return `<div class="file bg-dark-subtle text-dark rounded-3 rounded-bottom-0 position-relative">
                                                <i class="fa-solid fa-file display-6 mb-3"></i>
                                                <span class="fs-6 fw-light mb-2 px-3 text-center">${other.name}</span>
                                                <div class="actions position-relative">
                                                    <a href="${other.url}" target="_blank" class="me-2">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </a>
                                                    <a href="${other.url}" download="${other.name}">
                                                        <i class="fa-solid fa-circle-down"></i>
                                                    </a>
                                                </div>
                                            </div>`
                }
                $(`.list-group-item[data-id=${data.senderId}]`).find('.profileContent small').text(data.message)
                $(`#remarks[data-id=${data.senderId}]`).prepend(`<div class="w-100 d-flex ${data.hasOwnProperty('other') != '' ? 'flex-column' : ''} justify-content-start mb-2 appendedMessage">
                                        ${data.hasOwnProperty('other') ? appendFile(data.other) : ''}
                                        <div class="mb-0 overflow-hidden text-${type == 'start' ? 'white' : 'dark'} rounded-3 ${data.hasOwnProperty('other') ? 'rounded-top-0 border-top w-100' : ''} text-wrap p-2 py-1 m-0 shadow-sm d-inline-block ${type == 'start' ? 'bg-dark' : 'bg-dark-subtle'}" style="max-width:50%;font-size:13px;word-break: break-all;">${data.message}</div>
                                    </div>`)
            }
            function selfAppendMessage(message,type,receiverId,name = '') {
                randomMakeId = makeid(10)
                let customProgress = (file_name) => {
                     return `<div class="file bg-dark text-white rounded-3 rounded-bottom-0 position-relative" data-uploadId="${randomMakeId}">
                                                <i class="fa-solid fa-file display-6 mb-3"></i>
                                                <span class="fs-6 fw-light mb-2 px-3 text-center">${name}</span>
                                                <div class="actions position-relative">
                                                    <div class="customProgress rounded-pill overflow-hidden" data-percentage="0%">
                                                        <div class="innerCustomProgress" style="width:0%">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>`
                };
                                            $(`.employeeList[data-id=${receiverId}]`).find('.profileContent small').text(message)
                                            $(`#remarks`).prepend(`<div class="w-100 d-flex flex-column align-items-end mb-2 appendedMessage">
                                        ${name != '' ? customProgress(name) : ''}
                                        <div class="mb-0 overflow-hidden text-white rounded-3 ${name != '' ? 'rounded-top-0 border-top w-100' : ''}   text-wrap p-2 py-1 m-0 shadow-sm d-inline-block bg-dark" style="max-width:50%;font-size:13px;word-break: break-all;">${message}<br><small class="float-end messageTime">${getCurrentTime()}</small></div>
                                        
                                    </div>`)
                                    
                const changePositionHtml = $(`#chattedEMpList .employeeList[data-id=${receiverId}]`).prop('outerHTML');
                $(`#chattedEMpList .employeeList[data-id=${receiverId}]`).remove()
                $(`#chattedEMpList ul`).prepend(changePositionHtml)
            }
            
            
        })
        
    </script>
    
        <?php $__env->stopPush(); ?>
        
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('office.partical.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u911317397/domains/lightsalmon-quetzal-130864.hostingersite.com/public_html/resources/views/office/chats/index.blade.php ENDPATH**/ ?>