<?php echo $__env->make('office.partical.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('office.partical.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/u911317397/domains/lightsalmon-quetzal-130864.hostingersite.com/public_html/resources/views/office/partical/main.blade.php ENDPATH**/ ?>