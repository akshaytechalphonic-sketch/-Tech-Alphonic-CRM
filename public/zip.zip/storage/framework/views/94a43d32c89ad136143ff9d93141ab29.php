<?php $__env->startPush('title'); ?>
    <title>Dashboard | Admin</title>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="main-content">
        <!-- write-body-content here start -->
        <div class="pages-content">
            <div class="dash-tabs d-flex justify-content-between  align-items-center mb-3 d-none">
                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                    <!-- <li class="nav-item me-3">
                                    <button class="client-main-btn" type="button" > Employee <img src="../assets/images/icons/double-arrow.png" alt=""> </button>
                                </li> -->
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active rounded-pill" id="pills-Allclient-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-Allclient" type="button" role="tab" aria-controls="pills-Allclient"
                            aria-selected="true">All Employees </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link rounded-pill" id="pills-Activeclient-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-Activeclient" type="button" role="tab"
                            aria-controls="pills-Activeclient" aria-selected="false">Departments </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link rounded-pill" id="pills-InActiveclient-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-InActiveclient" type="button" role="tab"
                            aria-controls="pills-InActiveclient" aria-selected="false">Designations </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link rounded-pill" id="pills-Completedclient-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-Completedclient" type="button" role="tab"
                            aria-controls="pills-Completedclient" aria-selected="false">Employee Shift </button>
                    </li>
                </ul>

                <div class="dash-tabs-filter  d-flex gap-3">
                    <!-- <div class="filter-btn">
                                    <a href="#!" class="d-flex align-items-center gap-2"  data-bs-toggle="modal" data-bs-target="#filterModel"> <img src="../assets/images/icons/setting.png" alt="">Filter</a>
                                </div> -->
                    <div class="create-client-btn">
                        <a href="<?php echo e(route('admin.office.create')); ?>" class="d-flex align-items-center gap-2"> <img
                                src="<?php echo e(asset('public/admin/assets/images/icons/plus.png')); ?>" alt="">Add
                            Employee</a>
                    </div>

                </div>
            </div>

            <div class="dash-tabs-content no-scrollbar">
                <div class="container-fluid py-4 px-5">
                    <div class="row">
                        <div class="col-md-12">

                            <div class="step-form">
                                <div class="step-form-step active">
                                    <form action="<?php echo e(route('admin.office.create')); ?>" method="post"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-lg-12 mb-3">
                                                <div class="step-title ">
                                                    <h3>Add New Employee</h3>
                                                </div>
                                            </div>

                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">Name </label>
                                                <input type="text" class="form-control" id="" placeholder="Name"
                                                    name="name" required>
                                            </div>
                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">Email </label>
                                                <input type="email" class="form-control" id=""
                                                    placeholder="Email" name="email" required>
                                            </div>
                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">Mobile No </label>
                                                <input type="tel" class="form-control" id=""
                                                    placeholder="Mobile No " name="mobile_n o" required>
                                            </div>
                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">Select Gender</label>
                                                <select class="form-select" aria-label="Default select example"
                                                    name="gender" required>
                                                    <option value="" disabled selected>Choose Gender</option>
                                                    <option value="Male">Male </option>
                                                    <option value="Female">Female</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">DOB (Date of Birth) </label>
                                                <input type="date" class="form-control" id=""
                                                    placeholder="DOB" name="dob" required>
                                            </div>
                                            
                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">Select Shift</label>
                                                <select class="form-select" aria-label="Default select example"
                                                    name="shift" required>
                                                    <option value="" disabled selected>Choose Shift</option>
                                                    <option value="Day">Day </option>
                                                    <option value="Night">Night</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">Select Designation</label>
                                                <select class="form-select" aria-label="Default select example"
                                                    name="designation_id" required>
                                                    <option value="" disabled selected>Choose Designation</option>
                                                    <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($items->id); ?>"
                                                            data-salesEmp="<?php echo e($items->department->department_name == 'Sales' ? 'true' : 'false'); ?>">
                                                            <?php echo e($items->designation_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                
                                                <input type="number" name="monthly_sales_target" id="monthlySalesTarget"
                                                    class="form-control mt-2 d-none"
                                                    placeholder="Enter Monthly Sales Target">
                                                
                                            </div>
                                            <div class="col-lg-3 col-md-6 mb-3">
                                                <label for="" class="form-label">Password </label>
                                                <input type="password" class="form-control" id=""
                                                    placeholder="Name" name="password" required>
                                            </div>
                                            
                                        </div>
                                        <div
                                            class="next-preview-btns d-flex align-items-center justify-content-between mt-4">
                                            <a href="<?php echo e(url()->previous()); ?>" class=" prev-step">Cancel</a>
                                            <button class=" confirm-step" type="submit">Submit</button>
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>




        <!-- write-body-content here end -->
    </div>

    </div>
    </section>

    <div class="search-box-mob">
        <div class="close-search-bar">
            <img width="30" height="30" src="https://img.icons8.com/ios/30/close-window.png"
                alt="close-window" />
        </div>


        <?php $__env->startPush('custom-js'); ?>
            <script>
                $(document).ready(function() {
                    $('input[type=file]').change(function() {
                        let innersec = $(this).parent()[0];
                        $(innersec).find('span').removeClass('d-none')
                    })
                    $("select[name=designation_id]").change(function() {
                        const isSalesEmp = $(this).find(':selected').data('salesemp');
                        if (isSalesEmp == true) {
                            $('#monthlySalesTarget').removeClass('d-none')
                            $('#monthlySalesTarget').val(null)
                        } else {
                            $('#monthlySalesTarget').addClass('d-none')
                        }
                    })
                })
            </script>
        <?php $__env->stopPush(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partical.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u911317397/domains/lightsalmon-quetzal-130864.hostingersite.com/public_html/resources/views/admin/office/create.blade.php ENDPATH**/ ?>