
<?php $__env->startPush('title'); ?>
    <title>Dashboard | Admin</title>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = \Request::route()->getName();

    ?>

    <div class="main-content">
        <!-- write-body-content here start -->
        <div class="pages-content">
            <div class="container-fluid">
                <div class="row">
                    <?php if($lead->csv != null): ?>
                        <?php
                            $lead_csv_json = json_decode($lead->csv, true);
                        ?>
                        <div class="col-12 mb-3">
                            <div class="accordion accordion-flush" id="accordionFlushExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#flush-collapseOne" aria-expanded="false"
                                            aria-controls="flush-collapseOne">
                                            Csv Data
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOne" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionFlushExample">
                                        <div class="accordion-body row">
                                            <?php $__currentLoopData = $lead_csv_json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                                                    <label for=""
                                                        class="form-label text-capitalize"><?php echo e(str_replace('_', ' ', $key)); ?></label>
                                                    <input type="text" class="form-control" value="<?php echo e($dt); ?>"
                                                        readonly>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="col-4">
                        <div class="bg-white rounded p-3 h-100">
                            <div class="step-title mb-4">
                                <h6>Employee Details</h6>
                            </div>
                            <ul class="list-group">
                                <li class="list-group-item mb-2"><strong>Service Name</strong> : <?php echo e($lead->service_name); ?>

                                </li>
                                <li class="list-group-item mb-2"><strong>Client Name</strong> : <?php echo e($lead->client_name); ?>

                                </li>
                                <li class="list-group-item mb-2"><strong>Client Mobile</strong> : <?php echo e($lead->client_mobile); ?>

                                </li>
                                <li class="list-group-item mb-2"><strong>Client Email</strong> : <?php echo e($lead->client_email); ?>

                                </li>
                                <li class="list-group-item mb-2"><strong>Amount</strong> :
                                    <?php echo e(number_format($lead->amount)); ?></li>
                                <li class="list-group-item mb-2"><strong>Final Amount</strong> :
                                    <?php echo e(number_format($lead->final_amount)); ?></li>
                                <li class="list-group-item mb-2"><strong>Recived Amount</strong> :
                                    <?php echo e(number_format($lead->recived_amount)); ?></li>
                                <li class="list-group-item mb-2"><strong>Pending Amount</strong> :
                                    <?php echo e(number_format($lead->final_amount - $lead->recived_amount)); ?></li>
                                <li class="list-group-item mb-2"><strong>status</strong> : <?php echo e($lead->status); ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-8">
                        <div class="bg-white rounded p-3 h-100">
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="btn btn-dark btn-sm py-1 active me-2" id="pills-home-tab"
                                        data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab"
                                        aria-controls="pills-home" aria-selected="true">Remarks 📜</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="btn btn-dark btn-sm py-1" id="pills-profile-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-profile" type="button" role="tab"
                                        aria-controls="pills-profile" aria-selected="false">Follow ups 📁</button>
                                </li>
                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                    aria-labelledby="pills-home-tab" tabindex="0">
                                    <!--<button class="btn btn-dark btn-sm py-1" data-bs-toggle="modal" data-bs-target="#exampleModal">Follow ups 📁</button>-->
                                    <div class="position-relative">
                                        <div id="remarks" class="bg-light mb-3 rounded p-3"
                                            style="height: 400px; overflow-y:scroll;scroll-behavior: smooth;flex-direction: column-reverse;">
                                            <?php
                                                $remark_json = json_decode($lead->remark, true);
                                            ?>

                                            <?php $__currentLoopData = $remark_json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p
                                                    class="mb-2 bg-white rounded text-wrap p-2 <?php echo e(count($remark_json) == $key + 1 ? 'mb-0' : ''); ?>">
                                                    <?php echo e($remark['remark']); ?><br>
                                                    <?php $__currentLoopData = $remark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ky => $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($ky != 'remark'): ?>
                                                            <span
                                                                class="badge bg-primary-subtle text-dark mt-2 text-capitalize"><?php echo e(str_replace('_', ' ', $ky)); ?>

                                                                :
                                                                <?php echo e($mark); ?></span>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <span
                                            class="badge rounded-pill bg-light text-bg-light justify-content-center align-items-center border position-absolute"
                                            id="scrollToBottomBtn"
                                            style="width:40px;height:40px;right:50px;bottom:30px;cursor: pointer;"><i
                                                class="fa-solid fa-chevron-down"></i></span>
                                    </div>
                                    <form class="row m-0"
                                        action="<?php echo e(route('office_employee.leads.update_lead_remark', ['id' => $lead->id])); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-6 mb-3">
                                            <label for="" class="form-label">Final Amount</label>
                                            <input type="number" class="form-control" value="<?php echo e($lead->final_amount); ?>"
                                                placeholder="Final amount" name="final_amount">
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label for="" class="form-label">Received Amount</label>
                                            <input type="number" class="form-control" value="<?php echo e($lead->recived_amount); ?>"
                                                placeholder="Recived mount" name="recived_amount">
                                        </div>
                                        <div class="col-9 pe-0">
                                            <textarea name="remark" class="form-control" placeholder="Write Remark" rows="3" required></textarea>
                                        </div>

                                        <div class="col-3">
                                            <select class="form-select mb-2" aria-label="Default select example"
                                                name="status" required>
                                                <option value="" selected disabled>Choose status</option>
                                                <option value="open" <?php echo e($lead->status == 'open' ? 'selected' : ''); ?>>
                                                    Open</option>
                                                <option value="hot" <?php echo e($lead->status == 'hot' ? 'selected' : ''); ?>>Hot
                                                </option>
                                                <option value="warm" <?php echo e($lead->status == 'warm' ? 'selected' : ''); ?>>
                                                    Warm</option>
                                                <option value="cold" <?php echo e($lead->status == 'cold' ? 'selected' : ''); ?>>
                                                    Cold</option>
                                                <option value="fake" <?php echo e($lead->status == 'fake' ? 'selected' : ''); ?>>
                                                    Fake</option>
                                                <option value="future" <?php echo e($lead->status == 'future' ? 'selected' : ''); ?>>
                                                    Future</option>
                                                <option value="loss" <?php echo e($lead->status == 'loss' ? 'selected' : ''); ?>>
                                                    Loss</option>
                                                <option value="connected"
                                                    <?php echo e($lead->status == 'connected' ? 'selected' : ''); ?>>Connected</option>
                                                <option value="not connected"
                                                    <?php echo e($lead->status == 'not connected' ? 'selected' : ''); ?>>Not Connected
                                                </option>
                                                <option value="converted"
                                                    <?php echo e($lead->status == 'converted' ? 'selected' : ''); ?>>Converted</option>
                                            </select>
                                            <button type="submit" class="btn btn-primary w-100">Submit</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                    aria-labelledby="pills-profile-tab" tabindex="0">
                                    <div class="position-relative">

                                        <div id="followups" class="bg-light mb-3 rounded p-3"
                                            style="height: 400px; overflow-y:scroll;scroll-behavior: smooth;flex-direction: column-reverse;">
                                            <?php $__currentLoopData = $followups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p
                                                    class="mb-2 bg-white rounded text-wrap p-2 <?php echo e(count($remark_json) == $key + 1 ? 'mb-0' : ''); ?>">
                                                    <?php echo e($item->content); ?><br>
                                                    <span
                                                        class="badge bg-primary-subtle text-dark mt-2 text-capitalize">Date:
                                                        <?php echo e(date('d M,Y', strtotime($item->date))); ?></span>
                                                    <span
                                                        class="badge bg-primary-subtle text-dark mt-2 text-capitalize">Time:
                                                        <?php echo e(date('h:i A', strtotime($item->time))); ?></span>
                                                </p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <form class="row m-0"
                                        action="<?php echo e(route('office_employee.leads.followup', ['lead_id' => $lead->id])); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-6 mb-3">
                                            <label for="" class="form-label">Date</label>
                                            <input type="date" class="form-control" min="<?php echo e(date('Y-m-d')); ?>"
                                                name="date">
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label for="" class="form-label">Time</label>
                                            <input type="time" class="form-control" name="time" min="10:00"
                                                max="19:00">
                                        </div>
                                        <div class="col-9 pe-0">
                                            <textarea name="content" class="form-control" placeholder="Write follow Up" rows="1" required></textarea>
                                        </div>
                                        <div class="col-3">
                                            <button type="submit" class="btn btn-primary w-100">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- write-body-content here end -->
    </div>

    </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form class="modal-content" action="<?php echo e(route('office_employee.leads.followup', ['lead_id' => $lead->id])); ?>"
                method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Followups</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="row m-0 modal-body">
                    <div class="col-md-6">
                        <label class="form-label">Date</label>
                        <input type="date" class="form-control" min="<?php echo e(date('Y-m-d')); ?>" name="date">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Time</label>
                        <input type="time" class="form-control" name="time" min="10:00" max="19:00">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Content</label>
                        <textarea class="form-control" rows="3" name="content"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
    <div class="search-box-mob">
        <div class="close-search-bar">
            <img width="30" height="30" src="https://img.icons8.com/ios/30/close-window.png"
                alt="close-window" />
        </div>

        <?php $__env->startPush('custom-js'); ?>
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    const remarksDiv = document.getElementById("remarks");
                    if (remarksDiv) {
                        remarksDiv.scrollTop = remarksDiv.scrollHeight;
                    }
                });
                document.addEventListener("DOMContentLoaded", function() {
                    const remarksDiv = document.getElementById("remarks");
                    const scrollToBottomBtn = document.getElementById("scrollToBottomBtn");

                    // Show/hide button based on scroll position
                    remarksDiv.addEventListener("scroll", function() {
                        const isAtBottom = remarksDiv.scrollHeight == Math.round(remarksDiv.scrollTop + remarksDiv
                            .clientHeight + 1) ? true : false;
                        console.log(remarksDiv.scrollHeight, Math.round(remarksDiv.scrollTop + remarksDiv
                            .clientHeight + 1))
                        scrollToBottomBtn.style.display = isAtBottom ? "none" : "flex";
                    });

                    // Scroll to bottom when button is clicked
                    scrollToBottomBtn.addEventListener("click", function() {
                        remarksDiv.scrollTop = remarksDiv.scrollHeight;
                    });
                });
            </script>
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    const remarksDiv = document.getElementById("followups");
                    if (remarksDiv) {
                        remarksDiv.scrollTop = remarksDiv.scrollHeight;
                    }
                });
                document.addEventListener("DOMContentLoaded", function() {
                    const remarksDiv = document.getElementById("followups");
                    const scrollToBottomBtn = document.getElementById("scrollToBottomBtn");

                    // Show/hide button based on scroll position
                    remarksDiv.addEventListener("scroll", function() {
                        const isAtBottom = remarksDiv.scrollHeight == Math.round(remarksDiv.scrollTop + remarksDiv
                            .clientHeight + 1) ? true : false;
                        console.log(remarksDiv.scrollHeight, Math.round(remarksDiv.scrollTop + remarksDiv
                            .clientHeight + 1))
                        scrollToBottomBtn.style.display = isAtBottom ? "none" : "flex";
                    });

                    // Scroll to bottom when button is clicked
                    scrollToBottomBtn.addEventListener("click", function() {
                        remarksDiv.scrollTop = remarksDiv.scrollHeight;
                    });
                });
            </script>
        <?php $__env->stopPush(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('office.partical.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u911317397/domains/lightsalmon-quetzal-130864.hostingersite.com/public_html/resources/views/office/leads/single-lead.blade.php ENDPATH**/ ?>