<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    

    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css" rel="stylesheet" />
    <!-- DataTables Buttons CSS -->
    <link href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css" rel="stylesheet" />

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/responsive.css')); ?>" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body>
    <section class="dashboard-main">
        <div class="header d-flex justify-content-between">
            <div class="d-flex align-items-center gap-4">
                <div class="desktop-toggle">
                    <div class="">
                        <a a href="javascript: history.go(-1)">
                            <img src="<?php echo e(asset('public/admin/assets/images/icons/arrow.png')); ?>" alt="" />
                        </a>
                    </div>
                    
                </div>
                <div class="mob-toggle">
                    <div class="toggle-btn">
                        <img width="32" height="30"
                            src="https://img.icons8.com/external-creatype-glyph-colourcreatype/36/external-hamburger-basic-creatype-glyph-colourcreatype-5.png"
                            alt="external-hamburger-basic-creatype-glyph-colourcreatype-5" />
                    </div>
                </div>
                <div class="welcome-admin">
                    <h3 class="fs-5 fw-4 mb-0 d-lg-block d-none">Welcome,
                        <?php echo e(Auth::guard('office_employees')->user()->name); ?></h3>
                </div>
            </div>
            <div class="header-right d-flex align-items-center gap-4">
                <div class="search-bar">
                    <img src="<?php echo e(asset('public/admin/assets/images/icons/search-icon.png')); ?>" alt="" />
                    <input type="text" placeholder="Search..." />
                </div>
                <?php
                    $followups = \App\Models\OfficeLeadFollowups::with('employee')
                        ->where('date', date('Y-m-d'))
                        ->where('time', '>=', date('H:i:s'))
                        ->where('active', 1)
                        ->where('emp_id', auth()->guard('office_employees')->user()->id)
                        ->get();
                ?>

                <div class="dropdown">
                    <div class="notification position-relative" type="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <img src="<?php echo e(asset('public/admin/assets/images/icons/notification-icon.png')); ?>"
                            alt="" />
                        <div class="notification-indication"><?php echo e($followups->count()); ?></div>
                    </div>

                    <ul class="dropdown-menu">
                        <?php $__empty_1 = true; $__currentLoopData = $followups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li>
                                <a class="dropdown-item"
                                    href="<?php echo e(route('office_employee.leads.single_lead', ['id' => $fups->lead_id])); ?>">
                                    <strong>You have a new meeting at
                                        <?php echo e(date('h:i A', strtotime($fups->time))); ?></strong><br>
                                    <?php echo e($fups->content); ?><br>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li><span class="dropdown-item text-muted">No follow-ups for today</span></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <div class="profile d-flex align-items-center gap-2">
                    <div class="profile-img">
                        <img src="<?php echo e(asset('public/admin/assets/images/user.png')); ?>" alt="" />
                    </div>
                    <div class="user-info">
                        <h4 class="title"><?php echo e(Auth::guard('office_employees')->user()->name); ?></h4>
                        <h5 class="user-name"><?php echo e(Auth::guard('office_employees')->user()->email); ?></h5>
                    </div>
                    <div class="logout-dropdown">
                        <a href="<?php echo e(route('employee_logout')); ?>">Logout <i class="fa fa-sign-out"
                                aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="mob-menu-layer"></div>
        <div class="sidebar sidebar-mob">
            <div class="logo">
                <img class="full-logo" src="<?php echo e(asset('public/admin/assets/images/tech-logo.svg')); ?>" alt="" />
                <img class="half-logo" src="<?php echo e(asset('public/admin/assets/images/favicon.png')); ?>" alt="" />
                <div class="close-mob-menu">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/close-window.png"
                        alt="close-window" />
                </div>
            </div>
            <div class="sidebar-menu">
                <div class="menu-list">
                    <ul>
                        <li class="menu-item">
                            <a href="<?php echo e(route('office_employee.employee_dashboard')); ?>"
                                class="<?php echo e(request()->routeIs('office_employee.dashboard') ? 'active' : ''); ?>"><img
                                    src="<?php echo e(asset('public/admin/assets/images/icons/icon1.png')); ?>" alt="" />
                                <span class="item-name">My Dashboard</span></a>
                        </li>

                        <li class="menu-item menu-dropdown">
                            <a href="#!"
                                class="<?php echo e(Request::is('admin/office') || Request::is('admin/office-attendance') || Request::is('admin/office-leads') ? 'active' : ''); ?>"><img
                                    src="<?php echo e(asset('public/admin/assets/images/icons/icon2.png')); ?>" alt="" />
                                <span class="item-name">My Office</span><img class="dropdown-icon"
                                    src="<?php echo e(asset('public/admin/assets/images/icons/arrow-right.png')); ?>"
                                    alt="" /></a>
                            <div class="dropdown-menu-sidebar" style="display: <?php echo e(Request::is('admin/office') || Request::is('admin/office-attendance') || Request::is('admin/office-leads') ? 'block' : ''); ?>;">
                                <ul>
                                    <li class="dropdown-item-sidebar">
                                        <a href="<?php echo e(route('office_employee.leads.index')); ?>"
                                            class="<?php echo e(Request::is('admin/office-leads') ? 'active' : ''); ?>"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/date-time.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Leads</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="<?php echo e(route('office_employee.chats.index')); ?>"
                                            class="<?php echo e(Request::is('admin/office-leads') ? 'active' : ''); ?>"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/date-time.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Messenger</span></a>
                                    </li>
                                    
                                </ul>
                            </div>
                        </li>


                        <li class="menu-item menu-dropdown d-none">
                            <a href="#!"
                                class="<?php echo e(request()->routeIs('admin.client.*', 'admin.employee.*') ? 'active' : ''); ?>"><img
                                    src="<?php echo e(asset('public/admin/assets/images/icons/icon2.png')); ?>" alt="" />
                                <span class="item-name">My Client</span><img class="dropdown-icon"
                                    src="<?php echo e(asset('public/admin/assets/images/icons/arrow-right.png')); ?>"
                                    alt="" /></a>
                            <div class="dropdown-menu-sidebar">
                                <ul>
                                    <li
                                        class="dropdown-item-sidebar <?php echo e(request()->routeIs('admin.client.index') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('admin.client.index')); ?>"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/users.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Client</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="<?php echo e(route('admin.employee.index')); ?>"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/person-board.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Employee</span></a>
                                    </li>



                                    <li class="dropdown-item-sidebar">
                                        <a href="adminwages.php"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/icon5.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Edit Wages</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/date-time.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Attendance</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="adminsalery.php"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/salary.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Salary</span></a>
                                    </li>
                                </ul>
                            </div>
                        </li>


                        <li class="menu-item menu-dropdown d-none">
                            <a href="#!"><img src="<?php echo e(asset('public/admin/assets/images/icons/icon2.png')); ?>"
                                    alt="" />
                                <span class="item-name">Accounts</span><img class="dropdown-icon"
                                    src="<?php echo e(asset('public/admin/assets/images/icons/arrow-right.png')); ?>"
                                    alt="" /></a>
                            <div class="dropdown-menu-sidebar">
                                <ul>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/users.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Client</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="<?php echo e(route('admin.employee.index')); ?>"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/person-board.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Employee</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/icon5.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Edit Wages</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/date-time.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Attendance</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/salary.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Salary</span></a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="menu-item menu-dropdown d-none">
                            <a href="#!"><img src="<?php echo e(asset('public/admin/assets/images/icons/icon2.png')); ?>"
                                    alt="" />
                                <span class="item-name">Bid Management</span><img class="dropdown-icon"
                                    src="<?php echo e(asset('public/admin/assets/images/icons/arrow-right.png')); ?>"
                                    alt="" /></a>
                            <div class="dropdown-menu-sidebar">
                                <ul>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/users.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Client</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/person-board.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Employee</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/icon5.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Edit Wages</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="#!"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/date-time.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Attendance</span></a>
                                    </li>
                                    <li class="dropdown-item-sidebar">
                                        <a href="saler#!hp"><img
                                                src="<?php echo e(asset('public/admin/assets/images/icons/salary.png')); ?>"
                                                alt="" />
                                            <span class="item-name">Salary</span></a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
<?php /**PATH /home/u911317397/domains/lightsalmon-quetzal-130864.hostingersite.com/public_html/resources/views/office/partical/header.blade.php ENDPATH**/ ?>