<?php echo $__env->make('admin.partical.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('admin.partical.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/u911317397/domains/lightsalmon-quetzal-130864.hostingersite.com/public_html/resources/views/admin/partical/main.blade.php ENDPATH**/ ?>